﻿namespace GGB_Cherry_Code
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num1;
            int num2;
            while (true)
            {
                Console.WriteLine("Please input a positive integer.");

                //Check if input is a positive integer
                bool isInt = int.TryParse(Console.ReadLine(), out int num);

                //If positive integer, assign value and break loop, else loop
                if (num! >= 0 && isInt == true)
                {
                    num1 = num;
                    break;
                }
                else
                {
                    Console.WriteLine("Input must be a positive integer.");
                }
            }

            while (true)
            {
                Console.WriteLine("Please input another positive integer.");
                
                //Check if input is a positive integer
                bool isInt = int.TryParse(Console.ReadLine(), out int num);

                //If positive integer, assign value and break loop, else loop
                if (num! >= 0 && isInt == true)
                {
                    num2 = num;
                    break;
                }
                else
                {
                    Console.WriteLine("Input must be a positive integer.");
                }
            }

            //Add the two inputed integers
            int number = num1 + num2;

            int NumCutter(int number)
            {
                //Get the last digit
                int remainder = number % 10;

                //Seperate the last digit from the number
                int newNum = (number - remainder) / 10;

                //Add the results
                int result = remainder + newNum;

                Console.WriteLine(result);

                //Repeat until the result is a single digit
                if (result < 10)
                {
                    return result;
                }
                else
                {
                    return NumCutter(result);
                }
                
            }

            Console.WriteLine(NumCutter(number));

        }
    }
}
